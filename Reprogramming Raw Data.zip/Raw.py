#   ___             __         _            ___  _____                                          
#  / _ | ___  ___ _/ /_ _____ (_)__   ___  / _/ / _/ /_ _____  _______ ___ _______ ___  _______ 
# / __ |/ _ \/ _ `/ / // (_-</ (_-<  / _ \/ _/ / _/ / // / _ \/ __/ -_|_-</ __/ -_) _ \/ __/ -_)
#/_/ |_/_//_/\_,_/_/\_, /___/_/___/  \___/_/  /_//_/\_,_/\___/_/  \__/___/\__/\__/_//_/\__/\__/ 
#                  /___/__       __                                                             
#                     / _ \___ _/ /____ _                                                       
#                    / // / _ `/ __/ _ `/                                                       
#                   /____/\_,_/\__/\_,_/	    Author :: Kevin Nelson :: kpie314@gmail.com
import sys
import os
import csv

def readFile(n,delim):
	fileIN=n
	Data={}
	with open(fileIN) as csvfile:
		tableMain=csv.reader(csvfile,delimiter=delim)
		k=0
		for row in tableMain:
			Data[k]=row
			k+=1
	return(Data)

#data = readFile(sys.argv[1])

def RawParse(data):
	starts=[]
	ends=[]
	names=[]
	found=False
	for k in range(0,len(data)):
		if(len(data[k])==0):
			if(found):
				ends.append(k)
			found=False
			pass
		else:
			if(found==False):
				found=True
				names.append(data[k][0])
				starts.append(k+1)
#				names.append(data[k][0])
	if(len(ends)<len(starts)):
		ends.append(k)
#		if(len(data[k])>0):
#			if(data[k][0]=='Experiment Information'):
#				print('Fight')
#				while(k in data.keys()):
#					starts.append(k+1)
#					names.append(data[k][0])
#					while(len(data[k])!=0):
#						k+=1
#						if(k in data.keys()==False):
#							break
#					ends.append(k)
#					print('end Found : ' + str(k))
#					k+=1
	ret={}
	print 'Making Data With'
	print names
	print 'starts'
	print starts
	print 'ends'
	print ends
	
	if(len(ends)==len(starts) and len(starts)==len(names)):
		for k in range(0,len(names)):
			ret[names[k]]={}
			k3=0
			for k2 in range(starts[k],ends[k]):
				ret[names[k]][k3]=data[k2]
				k3+=1
	return(ret,names)
print('imports complete')
Data , names = RawParse(readFile('Baseline Poly Raw.csv',','))
print len(Data)
for k in Data:
	print k
	print len(Data[k]) 
	print(len(Data[k][Data[k].keys()[0]]))

















